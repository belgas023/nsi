#############
| Chevalier |
#############

Vous incarner un chevalier assiégée par une horde de monstre. 
Defendez vos terres contre l'envahisseur.
A chaque montre mort vous est conferé de l'experience. Completez 100 point d'experience pour recevoir des bonus.


Fleches du clavier pour se deplacer.
Espace pour attaquer.

